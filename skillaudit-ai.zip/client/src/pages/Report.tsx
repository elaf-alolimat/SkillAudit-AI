import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Brain,
  Loader2,
  ArrowLeft,
  TrendingUp,
  Target,
  AlertCircle,
  CheckCircle,
  Lightbulb,
  BarChart3,
  Award,
  ChevronRight,
  Zap,
} from "lucide-react";
import { useLocation as useWouterLocation } from "wouter";
import { motion } from "framer-motion";
import {
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";
import type { AssessmentReport, SkillScore } from "../../../drizzle/schema";

function ScoreRing({
  score,
  size = 120,
  label,
  color = "oklch(0.65 0.22 270)",
}: {
  score: number;
  size?: number;
  label: string;
  color?: string;
}) {
  const radius = (size - 16) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="oklch(0.22 0.02 260)"
            strokeWidth={8}
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth={8}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className="transition-all duration-1000"
            style={{ filter: `drop-shadow(0 0 6px ${color}60)` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-extrabold text-foreground">{Math.round(score)}</span>
          <span className="text-xs text-muted-foreground">/100</span>
        </div>
      </div>
      <span className="text-xs text-muted-foreground text-center">{label}</span>
    </div>
  );
}

function getScoreColor(score: number): string {
  if (score >= 80) return "oklch(0.75 0.18 150)";
  if (score >= 60) return "oklch(0.72 0.20 50)";
  if (score >= 40) return "oklch(0.65 0.22 270)";
  return "oklch(0.60 0.22 25)";
}

function getScoreLabel(score: number): string {
  if (score >= 80) return "Excellent";
  if (score >= 65) return "Good";
  if (score >= 50) return "Developing";
  if (score >= 35) return "Beginner";
  return "Needs Work";
}

function getReadinessLabel(score: number): string {
  if (score >= 80) return "Job Ready";
  if (score >= 65) return "Nearly Ready";
  if (score >= 50) return "Developing";
  return "Needs Improvement";
}

export default function Report() {
  const params = useParams<{ assessmentId: string }>();
  const assessmentId = parseInt(params.assessmentId ?? "0");
  const [, navigate] = useLocation();

  const { data, isLoading } = trpc.assessment.getWithQuestions.useQuery(
    { id: assessmentId },
    { enabled: !!assessmentId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-muted-foreground">Loading report...</p>
        </div>
      </div>
    );
  }

  if (!data?.assessment) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Report not found</p>
          <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  const { assessment, questions, answers } = data;
  const report = assessment.reportData as AssessmentReport | null;

  if (!report) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-primary animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Report is being generated...</p>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => window.location.reload()}
          >
            Refresh
          </Button>
        </div>
      </div>
    );
  }

  const skillScores = report.skillScores ?? [];
  const radarData = skillScores.slice(0, 6).map((s: SkillScore) => ({
    skill: s.skill.length > 10 ? s.skill.slice(0, 10) + "…" : s.skill,
    score: s.score,
    fullMark: 100,
  }));

  const barData = skillScores.map((s: SkillScore) => ({
    name: s.skill,
    score: Math.round(s.score),
    color: getScoreColor(s.score),
  }));

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/50 sticky top-0 z-10 backdrop-blur-sm">
        <div className="container">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/dashboard")}
                className="text-muted-foreground"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <div className="h-4 w-px bg-border" />
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Assessment Report</span>
              </div>
            </div>
            <Button
              size="sm"
              onClick={() => navigate("/setup")}
              className="glow-sm"
            >
              <Zap className="w-3.5 h-3.5 mr-1.5" />
              New Assessment
            </Button>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="max-w-4xl mx-auto space-y-6">

          {/* Hero scores */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 to-transparent p-8"
          >
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex gap-8">
                <ScoreRing
                  score={report.overallScore}
                  size={130}
                  label="Overall Score"
                  color={getScoreColor(report.overallScore)}
                />
                <ScoreRing
                  score={report.jobReadinessScore}
                  size={130}
                  label="Job Readiness"
                  color="oklch(0.70 0.20 200)"
                />
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
                  <Badge
                    variant="secondary"
                    className="capitalize bg-primary/10 text-primary border-primary/20"
                  >
                    {assessment.specialization}
                  </Badge>
                  <Badge
                    variant="secondary"
                    className="capitalize bg-secondary text-muted-foreground"
                  >
                    {assessment.experienceLevel}
                  </Badge>
                </div>
                <h1 className="text-2xl font-bold mb-1">
                  {getScoreLabel(report.overallScore)}
                </h1>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {report.summary}
                </p>
                <div className="mt-3 inline-flex items-center gap-1.5 text-sm">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: getScoreColor(report.jobReadinessScore) }}
                  />
                  <span className="text-muted-foreground">
                    Job Market Status:{" "}
                    <span className="font-medium text-foreground">
                      {getReadinessLabel(report.jobReadinessScore)}
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Charts row */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Radar chart */}
            {radarData.length >= 3 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="rounded-2xl border border-border/50 bg-card p-6"
              >
                <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                  <Target className="w-4 h-4 text-primary" />
                  Skill Radar
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="oklch(0.22 0.02 260)" />
                    <PolarAngleAxis
                      dataKey="skill"
                      tick={{ fill: "oklch(0.55 0.02 260)", fontSize: 11 }}
                    />
                    <Radar
                      name="Score"
                      dataKey="score"
                      stroke="oklch(0.65 0.22 270)"
                      fill="oklch(0.65 0.22 270)"
                      fillOpacity={0.25}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </motion.div>
            )}

            {/* Bar chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="rounded-2xl border border-border/50 bg-card p-6"
            >
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                Skill Scores
              </h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={barData} layout="vertical" margin={{ left: 0, right: 20 }}>
                  <XAxis type="number" domain={[0, 100]} tick={{ fill: "oklch(0.55 0.02 260)", fontSize: 10 }} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={80}
                    tick={{ fill: "oklch(0.55 0.02 260)", fontSize: 10 }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "oklch(0.14 0.018 260)",
                      border: "1px solid oklch(0.22 0.02 260)",
                      borderRadius: "8px",
                      color: "oklch(0.95 0.01 260)",
                    }}
                    formatter={(value: number) => [`${value}/100`, "Score"]}
                  />
                  <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                    {barData.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </motion.div>
          </div>

          {/* Strengths & Weaknesses */}
          <div className="grid md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-6"
            >
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2 text-emerald-400">
                <CheckCircle className="w-4 h-4" />
                Strengths
              </h3>
              <div className="space-y-2">
                {report.strengths.map((s, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                    {s}
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-6"
            >
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2 text-amber-400">
                <AlertCircle className="w-4 h-4" />
                Areas for Improvement
              </h3>
              <div className="space-y-2">
                {report.weaknesses.map((w, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 flex-shrink-0" />
                    {w}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Missing Skills */}
          {report.missingSkills.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="rounded-2xl border border-border/50 bg-card p-6"
            >
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                Skills to Develop
              </h3>
              <div className="flex flex-wrap gap-2">
                {report.missingSkills.map((skill, i) => (
                  <Badge
                    key={i}
                    variant="secondary"
                    className="bg-primary/5 text-muted-foreground border-primary/10"
                  >
                    + {skill}
                  </Badge>
                ))}
              </div>
            </motion.div>
          )}

          {/* Recommendations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
            className="rounded-2xl border border-border/50 bg-card p-6"
          >
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-primary" />
              Personalized Recommendations
            </h3>
            <div className="space-y-3">
              {report.recommendations.map((rec, i) => (
                <div
                  key={i}
                  className="flex items-start gap-3 p-3 rounded-xl bg-secondary/30 border border-border/30"
                >
                  <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-primary">{i + 1}</span>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{rec}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Job Market Readiness Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="rounded-2xl border border-border/50 bg-card p-6"
          >
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Award className="w-4 h-4 text-primary" />
              Job Market Readiness Analysis
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {report.marketReadinessDetails}
            </p>
          </motion.div>

          {/* Q&A Review */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45 }}
            className="rounded-2xl border border-border/50 bg-card p-6"
          >
            <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              Question Review
            </h3>
            <div className="space-y-4">
              {questions.map((q, i) => {
                const answer = answers.find((a) => a.questionId === q.id);
                const score = answer?.score ?? null;
                return (
                  <div
                    key={q.id}
                    className="rounded-xl border border-border/30 bg-secondary/20 p-4"
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <p className="text-sm font-medium text-foreground flex-1">
                        {i + 1}. {q.questionText}
                      </p>
                      {score !== null && (
                        <Badge
                          variant="secondary"
                          className={`flex-shrink-0 text-xs ${
                            score >= 70
                              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                              : score >= 40
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                              : "bg-red-500/10 text-red-400 border-red-500/20"
                          }`}
                        >
                          {Math.round(score)}/100
                        </Badge>
                      )}
                    </div>
                    {answer?.answerText && !answer.isSkipped && (
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                        Your answer: {answer.answerText}
                      </p>
                    )}
                    {answer?.isSkipped && (
                      <p className="text-xs text-amber-400/70 mb-2">Skipped</p>
                    )}
                    {answer?.feedback && (
                      <p className="text-xs text-muted-foreground/80 italic">
                        AI Feedback: {answer.feedback}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex gap-3"
          >
            <Button
              variant="outline"
              onClick={() => navigate("/dashboard")}
              className="flex-1"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <Button
              onClick={() => navigate("/setup")}
              className="flex-1 glow-sm"
            >
              <Zap className="w-4 h-4 mr-2" />
              Take Another Assessment
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

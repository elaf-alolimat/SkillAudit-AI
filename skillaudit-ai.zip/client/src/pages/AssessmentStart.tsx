import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Brain,
  Loader2,
  ArrowRight,
  Clock,
  Target,
  Zap,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";
import { motion } from "framer-motion";

export default function AssessmentStart() {
  const params = useParams<{ profileId: string }>();
  const profileId = parseInt(params.profileId ?? "0");
  const [, navigate] = useLocation();
  const [starting, setStarting] = useState(false);

  const { data: profile, isLoading } = trpc.skillProfile.getById.useQuery(
    { id: profileId },
    { enabled: !!profileId }
  );

  const startAssessment = trpc.assessment.start.useMutation();

  const handleStart = async () => {
    setStarting(true);
    try {
      const result = await startAssessment.mutateAsync({ skillProfileId: profileId });
      navigate(`/assessment/${result.assessmentId}`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to start assessment. Please try again.");
      setStarting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Profile not found</p>
          <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
        </div>
      </div>
    );
  }

  const skills = profile.skills as string[];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/50">
        <div className="container">
          <div className="flex items-center gap-4 h-16">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/dashboard")}
              className="text-muted-foreground"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">Assessment Preview</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-10"
          >
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4 glow-sm">
              <Brain className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold mb-2">Ready for Your Assessment?</h1>
            <p className="text-muted-foreground">
              AI will generate 10 personalized technical questions based on your profile.
            </p>
          </motion.div>

          {/* Profile summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="rounded-2xl border border-border/50 bg-card p-6 mb-6"
          >
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wide">
              Your Profile
            </h3>
            <div className="flex flex-wrap gap-3 mb-4">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{profile.specialization}</span>
              </div>
              <Badge
                variant="secondary"
                className="capitalize bg-primary/10 text-primary border-primary/20"
              >
                {profile.experienceLevel} Level
              </Badge>
              {profile.source === "resume" && (
                <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                  From Resume
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {skills.slice(0, 12).map((skill) => (
                <Badge key={skill} variant="outline" className="text-xs border-border/50 text-muted-foreground">
                  {skill}
                </Badge>
              ))}
              {skills.length > 12 && (
                <Badge variant="outline" className="text-xs border-border/50 text-muted-foreground">
                  +{skills.length - 12} more
                </Badge>
              )}
            </div>
          </motion.div>

          {/* Assessment details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-3 gap-4 mb-8"
          >
            {[
              { icon: Target, label: "Questions", value: "10", color: "text-violet-400" },
              { icon: Clock, label: "Time Limit", value: "5 min/Q", color: "text-cyan-400" },
              { icon: Zap, label: "Difficulty", value: "Adaptive", color: "text-amber-400" },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-xl border border-border/50 bg-card p-4 text-center"
              >
                <item.icon className={`w-5 h-5 mx-auto mb-2 ${item.color}`} />
                <div className="font-semibold text-sm">{item.value}</div>
                <div className="text-xs text-muted-foreground">{item.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Instructions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-2xl border border-border/50 bg-card p-6 mb-8"
          >
            <h3 className="text-sm font-semibold mb-3">Before You Start</h3>
            <div className="space-y-2">
              {[
                "Answer each question as thoroughly as possible for the best evaluation",
                "You can skip questions, but it will affect your score",
                "Each question has a 5-minute timer — manage your time wisely",
                "Your answers will be evaluated by AI for accuracy and depth",
              ].map((tip, i) => (
                <div key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                  {tip}
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex gap-3"
          >
            <Button
              variant="outline"
              onClick={() => navigate("/dashboard")}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleStart}
              disabled={starting}
              className="flex-1 glow-sm"
              size="lg"
            >
              {starting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Questions...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Start Assessment
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import {
  Brain,
  FileText,
  Zap,
  BarChart3,
  CheckCircle,
  ArrowRight,
  Star,
  Target,
  TrendingUp,
  Shield,
  ChevronRight,
  Sparkles,
  Code2,
  Award,
  Users,
} from "lucide-react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
};

const features = [
  {
    icon: FileText,
    title: "Resume Analysis",
    description:
      "Upload your PDF resume and let AI automatically extract your skills, specialization, and experience level with precision.",
    color: "oklch(0.65 0.22 270)",
    gradient: "from-violet-500/20 to-purple-500/10",
  },
  {
    icon: Brain,
    title: "AI Question Generation",
    description:
      "Receive personalized technical questions crafted specifically for your skill set, specialization, and experience level.",
    color: "oklch(0.70 0.20 200)",
    gradient: "from-cyan-500/20 to-blue-500/10",
  },
  {
    icon: Zap,
    title: "Interactive Assessment",
    description:
      "Answer questions in a timed, interactive environment with a clear progress tracker and intuitive interface.",
    color: "oklch(0.75 0.18 150)",
    gradient: "from-emerald-500/20 to-teal-500/10",
  },
  {
    icon: BarChart3,
    title: "Detailed Reports",
    description:
      "Get a comprehensive visual report showing skill scores, job market readiness, and personalized improvement paths.",
    color: "oklch(0.72 0.20 50)",
    gradient: "from-amber-500/20 to-orange-500/10",
  },
  {
    icon: TrendingUp,
    title: "Progress Tracking",
    description:
      "Monitor your growth over time with a personal dashboard showing your assessment history and skill evolution.",
    color: "oklch(0.65 0.22 340)",
    gradient: "from-rose-500/20 to-pink-500/10",
  },
  {
    icon: Shield,
    title: "Secure Storage",
    description:
      "Your resume and assessment data are stored securely and linked to your account for easy future reference.",
    color: "oklch(0.68 0.20 230)",
    gradient: "from-blue-500/20 to-indigo-500/10",
  },
];

const steps = [
  {
    step: "01",
    title: "Upload or Enter Skills",
    description: "Upload your PDF resume or manually enter your technical skills and specialization.",
    icon: FileText,
  },
  {
    step: "02",
    title: "AI Analyzes Your Profile",
    description: "Our AI extracts and analyzes your skills, experience level, and technical specialization.",
    icon: Brain,
  },
  {
    step: "03",
    title: "Take the Assessment",
    description: "Answer 10 personalized technical questions tailored to your exact skill level.",
    icon: Code2,
  },
  {
    step: "04",
    title: "Receive Your Report",
    description: "Get a detailed visual report with scores, gaps, and actionable recommendations.",
    icon: Award,
  },
];

const stats = [
  { value: "10+", label: "Technical Questions", icon: Target },
  { value: "AI", label: "Powered Evaluation", icon: Brain },
  { value: "100%", label: "Personalized", icon: Sparkles },
  { value: "∞", label: "Assessments", icon: TrendingUp },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
        <div className="container">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center glow-sm">
                <Brain className="w-4.5 h-4.5 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg tracking-tight text-foreground">
                Skill<span className="gradient-text">Audit</span> AI
              </span>
            </div>

            {/* Nav links */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Features
              </a>
              <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                How It Works
              </a>
              <a href="#stats" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Why Us
              </a>
            </div>

            {/* CTA */}
            <div className="flex items-center gap-3">
              {isAuthenticated ? (
                <Button onClick={() => navigate("/dashboard")} size="sm" className="glow-sm">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Dashboard
                </Button>
              ) : (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => { window.location.href = getLoginUrl(); }}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    Sign In
                  </Button>
                  <Button size="sm" onClick={handleGetStarted} className="glow-sm">
                    Get Started Free
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-gradient pt-32 pb-24 overflow-hidden relative">
        {/* Decorative orbs */}
        <div className="absolute top-20 left-1/4 w-96 h-96 rounded-full bg-primary/5 blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-1/4 w-64 h-64 rounded-full bg-cyan-500/5 blur-3xl pointer-events-none" />

        <div className="container relative">
          <div className="max-w-4xl mx-auto text-center">
            {/* Logo Badge */}
            <motion.div initial="hidden" animate="visible" variants={fadeUp} custom={-1} className="mb-8">
              <div className="inline-flex items-center justify-center">
                <img 
                  src="/manus-storage/skillaudit-logo_a6ceea02.jpg" 
                  alt="SkillAudit AI" 
                  className="w-32 h-32 object-contain"
                />
              </div>
            </motion.div>

            <motion.div initial="hidden" animate="visible" variants={fadeUp} custom={0}>
              <Badge
                variant="secondary"
                className="mb-6 px-4 py-1.5 text-xs font-medium border border-primary/30 bg-primary/10 text-primary"
              >
                <Sparkles className="w-3 h-3 mr-1.5" />
                AI-Powered Technical Skills Assessment
              </Badge>
            </motion.div>

            <motion.h1
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              custom={1}
              className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-tight mb-6"
            >
              Know Your Real{" "}
              <span className="gradient-text">Technical Level</span>
              <br />
              Beyond the Resume
            </motion.h1>

            <motion.p
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              custom={2}
              className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              SkillAudit AI analyzes your resume, generates personalized technical questions, and
              produces a detailed assessment report — giving you an accurate picture of your job
              market readiness.
            </motion.p>

            <motion.div
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              custom={3}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <Button
                size="lg"
                onClick={handleGetStarted}
                className="px-8 py-6 text-base font-semibold glow-primary rounded-xl"
              >
                <Zap className="w-5 h-5 mr-2" />
                Start Your Free Assessment
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="px-8 py-6 text-base border-border/50 hover:border-primary/50 rounded-xl"
                onClick={() => document.getElementById("how-it-works")?.scrollIntoView({ behavior: "smooth" })}
              >
                See How It Works
              </Button>
            </motion.div>

            {/* Trust indicators */}
            <motion.div
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              custom={4}
              className="mt-12 flex items-center justify-center gap-6 text-sm text-muted-foreground"
            >
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                No credit card required
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Free to start
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Results in minutes
              </div>
            </motion.div>
          </div>

          {/* Hero visual - Mock assessment card */}
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-20 max-w-2xl mx-auto"
          >
            <div className="glass rounded-2xl p-6 border border-border/50 glow-sm float-animation">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-sm font-medium text-foreground">Assessment in Progress</span>
                </div>
                <Badge variant="secondary" className="text-xs bg-primary/10 text-primary border-primary/20">
                  Question 7 / 10
                </Badge>
              </div>

              <div className="mb-4">
                <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
                  <span>Progress</span>
                  <span>70%</span>
                </div>
                <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full w-[70%] bg-primary rounded-full" />
                </div>
              </div>

              <div className="bg-secondary/50 rounded-xl p-4 mb-4">
                <p className="text-sm text-foreground leading-relaxed">
                  Explain the difference between <code className="text-primary bg-primary/10 px-1 py-0.5 rounded text-xs">useEffect</code> and{" "}
                  <code className="text-primary bg-primary/10 px-1 py-0.5 rounded text-xs">useLayoutEffect</code> in React, and when would you use each?
                </p>
              </div>

              <div className="flex gap-2">
                {["React", "Hooks", "Performance"].map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs border-border/50 text-muted-foreground">
                    {tag}
                  </Badge>
                ))}
                <div className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                  <span className="text-amber-400 font-mono font-bold">02:34</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-16 border-y border-border/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl font-extrabold gradient-text mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24">
        <div className="container">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Badge variant="secondary" className="mb-4 bg-primary/10 text-primary border-primary/20">
                Platform Features
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Everything You Need to{" "}
                <span className="gradient-text">Prove Your Skills</span>
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                A complete AI-powered assessment platform designed to give you an accurate,
                objective evaluation of your technical capabilities.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className={`card-hover rounded-2xl p-6 border border-border/50 bg-card bg-gradient-to-br ${feature.gradient}`}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${feature.color}20`, border: `1px solid ${feature.color}30` }}
                >
                  <feature.icon className="w-5 h-5" style={{ color: feature.color }} />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 bg-card/30">
        <div className="container">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Badge variant="secondary" className="mb-4 bg-primary/10 text-primary border-primary/20">
                Simple Process
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                From Resume to Report in{" "}
                <span className="gradient-text">4 Simple Steps</span>
              </h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Our streamlined process takes you from profile setup to detailed assessment
                report in just a few minutes.
              </p>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="relative"
              >
                {i < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-gradient-to-r from-border to-transparent z-0" />
                )}
                <div className="relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-4 glow-sm">
                    <step.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div className="text-xs font-mono text-primary/60 mb-2">{step.step}</div>
                  <h3 className="font-semibold text-foreground mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center rounded-3xl p-12 border border-primary/20 bg-gradient-to-br from-primary/10 to-transparent glow-primary relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center mx-auto mb-6">
                <Brain className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Discover Your{" "}
                <span className="gradient-text">True Skill Level?</span>
              </h2>
              <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
                Join thousands of developers who have used SkillAudit AI to get an honest,
                AI-powered assessment of their technical skills.
              </p>
              <Button
                size="lg"
                onClick={handleGetStarted}
                className="px-10 py-6 text-base font-semibold glow-primary rounded-xl"
              >
                <Zap className="w-5 h-5 mr-2" />
                Start Free Assessment Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              <p className="mt-4 text-xs text-muted-foreground">
                No credit card required · Results in under 15 minutes
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border/30">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                <Brain className="w-3.5 h-3.5 text-primary-foreground" />
              </div>
              <span className="text-sm font-semibold text-foreground">
                Skill<span className="gradient-text">Audit</span> AI
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              © 2025 SkillAudit AI. Intelligent Skills Assessment Platform.
            </p>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>AI-Powered · Accurate · Personalized</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

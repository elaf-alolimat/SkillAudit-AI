export const SPECIALIZATION_CATEGORIES = {
  "💻 Information Technology & Computer Science": [
    "Computer Science",
    "Software Engineering",
    "Cybersecurity",
    "Artificial Intelligence",
    "Data Science",
    "Computer Networks",
  ],
  "🏥 Medical & Healthcare Field": [
    "Medicine",
    "Dentistry",
    "Pharmacy",
    "Nursing",
    "Physical Therapy",
    "Medical Laboratory Science",
  ],
  "🏗️ Engineering Field": [
    "Civil Engineering",
    "Mechanical Engineering",
    "Electrical Engineering",
    "Industrial Engineering",
    "Architectural Engineering",
  ],
  "💼 Business & Management Field": [
    "Business Administration",
    "Marketing",
    "Accounting",
    "Finance",
    "Human Resources",
  ],
  "⚖️ Law & Political Field": [
    "Law",
    "Political Science",
    "International Relations",
  ],
  "🔬 Science Field": [
    "Chemistry",
    "Physics",
    "Biology",
    "Mathematics",
  ],
  "📚 Humanities & Social Sciences": [
    "Psychology",
    "Sociology",
    "History",
    "Education",
  ],
};

export function searchSpecializations(query: string) {
  const lowerQuery = query.toLowerCase();
  const results: Record<string, string[]> = {};

  Object.entries(SPECIALIZATION_CATEGORIES).forEach(([category, specs]) => {
    const filtered = specs.filter((spec) =>
      spec.toLowerCase().includes(lowerQuery)
    );
    if (filtered.length > 0) {
      results[category] = filtered;
    }
  });

  return results;
}

export function getAllSpecializations() {
  return Object.values(SPECIALIZATION_CATEGORIES).flat();
}

import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { storagePut } from "./storage";
import * as pdfParseModule from "pdf-parse";
const pdfParse = (pdfParseModule as any).default ?? pdfParseModule;
import {
  createSkillProfile,
  getSkillProfilesByUser,
  getSkillProfileById,
  createAssessment,
  getAssessmentById,
  getAssessmentsByUser,
  updateAssessmentStatus,
  createQuestions,
  getQuestionsByAssessment,
  createAnswer,
  getAnswersByAssessment,
  updateAnswer,
  getAnswerByQuestionAndAssessment,
  incrementAnsweredQuestions,
} from "./db";
import type { AssessmentReport, SkillScore } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Skill Profiles ──────────────────────────────────────────────────────────
  skillProfile: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getSkillProfilesByUser(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const profile = await getSkillProfileById(input.id);
        if (!profile || profile.userId !== ctx.user.id) {
          throw new Error("Profile not found");
        }
        return profile;
      }),

    // Create from manual input
    createManual: protectedProcedure
      .input(
        z.object({
          specialization: z.string().min(1),
          experienceLevel: z.enum(["junior", "mid", "senior", "lead"]),
          skills: z.array(z.string().min(1)).min(1).max(30),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const profile = await createSkillProfile({
          userId: ctx.user.id,
          source: "manual",
          specialization: input.specialization,
          experienceLevel: input.experienceLevel,
          skills: input.skills,
        });
        return profile;
      }),

    // Analyze resume text with AI
    analyzeResume: protectedProcedure
      .input(
        z.object({
          resumeText: z.string().min(50),
          fileName: z.string(),
          fileKey: z.string().optional(),
          fileUrl: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are an expert recruiter and skills analyst across all fields. Analyze the provided resume text and extract structured information. Return ONLY valid JSON.`,
            },
            {
              role: "user",
              content: `Analyze this resume and extract:
1. Primary specialization (e.g., "Frontend Development", "Mechanical Engineering", "General Medicine", "Marketing", "Law", etc. - any field)
2. Experience level: "junior" (0-2 years), "mid" (2-5 years), "senior" (5-10 years), or "lead" (10+ years)
3. Skills list (relevant skills, tools, certifications, languages - max 20 most relevant)
4. A brief professional summary (2-3 sentences)

Resume text:
${input.resumeText}

Return JSON with this exact structure:
{
  "specialization": "string",
  "experienceLevel": "junior|mid|senior|lead",
  "skills": ["skill1", "skill2", ...],
  "summary": "string"
}`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "resume_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  specialization: { type: "string" },
                  experienceLevel: { type: "string", enum: ["junior", "mid", "senior", "lead"] },
                  skills: { type: "array", items: { type: "string" } },
                  summary: { type: "string" },
                },
                required: ["specialization", "experienceLevel", "skills", "summary"],
                additionalProperties: false,
              },
            },
          },
        });

        const rawContent = response.choices[0]?.message?.content;
        const content = typeof rawContent === 'string' ? rawContent : null;
        if (!content) throw new Error("AI analysis failed");

        const parsed = JSON.parse(content) as {
          specialization: string;
          experienceLevel: "junior" | "mid" | "senior" | "lead";
          skills: string[];
          summary: string;
        };

        const profile = await createSkillProfile({
          userId: ctx.user.id,
          source: "resume",
          specialization: parsed.specialization,
          experienceLevel: parsed.experienceLevel,
          skills: parsed.skills,
          rawResumeText: input.resumeText,
          resumeFileKey: input.fileKey,
          resumeFileUrl: input.fileUrl,
          resumeFileName: input.fileName,
          aiSummary: parsed.summary,
        });

        return { profile, analysis: parsed };
      }),

    // Upload resume PDF and extract text
    uploadResume: protectedProcedure
      .input(
        z.object({
          fileName: z.string(),
          fileBase64: z.string(),
          mimeType: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.fileBase64, "base64");
        const fileKey = `resumes/${ctx.user.id}/${Date.now()}-${input.fileName}`;
        const { key, url } = await storagePut(fileKey, buffer, input.mimeType);

        // Extract text from PDF
        let extractedText = "";
        try {
          const pdfData = await pdfParse(buffer);
          extractedText = pdfData.text ?? "";
        } catch (e) {
          console.warn("PDF text extraction failed:", e);
          extractedText = `[Resume file: ${input.fileName}]`;
        }

        return { key, url, extractedText };
      }),
  }),

  // ─── Assessments ─────────────────────────────────────────────────────────────
  assessment: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return getAssessmentsByUser(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const assessment = await getAssessmentById(input.id);
        if (!assessment || assessment.userId !== ctx.user.id) {
          throw new Error("Assessment not found");
        }
        return assessment;
      }),

    getWithQuestions: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const assessment = await getAssessmentById(input.id);
        if (!assessment || assessment.userId !== ctx.user.id) {
          throw new Error("Assessment not found");
        }
        const qs = await getQuestionsByAssessment(input.id);
        const ans = await getAnswersByAssessment(input.id);
        return { assessment, questions: qs, answers: ans };
      }),

    // Generate MCQ questions and start assessment
    start: protectedProcedure
      .input(z.object({ skillProfileId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const profile = await getSkillProfileById(input.skillProfileId);
        if (!profile || profile.userId !== ctx.user.id) {
          throw new Error("Skill profile not found");
        }

        const skills = profile.skills as string[];
        const topSkills = skills.slice(0, 8);

        // Generate MCQ questions via AI
        const isITSpecialization = profile.specialization?.toLowerCase().includes("technology") || profile.specialization?.toLowerCase().includes("it");
        const questionTypeRequirement = isITSpecialization 
          ? "- 5 questions should be practical/hands-on (code snippets, debugging, implementation scenarios)\n- 5 questions should be theoretical (concepts, best practices, architecture)\n"
          : "";
        
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a senior professional interviewer across all fields. Generate practical, insightful multiple-choice questions. Return ONLY valid JSON.`,
            },
            {
              role: "user",
              content: `Generate 10 multiple-choice questions for a ${profile.experienceLevel} ${profile.specialization} professional.
Skills to cover: ${topSkills.join(", ")}

Requirements:
- Mix of difficulty: 3 easy, 4 medium, 3 hard
- Each question must have exactly 4 options (A, B, C, D)
- Only ONE correct answer per question
- Options should be plausible but clearly differentiated
- Each question should clearly relate to a specific skill
- Include the correct answer index (0-3)
${questionTypeRequirement}

Return JSON with this structure:
{
  "questions": [
    {
      "questionText": "string",
      "skill": "string",
      "difficulty": "easy|medium|hard",
      "options": ["option A", "option B", "option C", "option D"],
      "correctOptionIndex": 0
    }
  ]
}`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "mcq_questions_generation",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  questions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        questionText: { type: "string" },
                        skill: { type: "string" },
                        difficulty: { type: "string", enum: ["easy", "medium", "hard"] },
                        options: { type: "array", items: { type: "string" }, minItems: 4, maxItems: 4 },
                        correctOptionIndex: { type: "integer", minimum: 0, maximum: 3 },
                      },
                      required: ["questionText", "skill", "difficulty", "options", "correctOptionIndex"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["questions"],
                additionalProperties: false,
              },
            },
          },
        });

        const rawContent2 = response.choices[0]?.message?.content;
        const content = typeof rawContent2 === 'string' ? rawContent2 : null;
        if (!content) throw new Error("Failed to generate questions");

        const parsed = JSON.parse(content) as {
          questions: Array<{
            questionText: string;
            skill: string;
            difficulty: "easy" | "medium" | "hard";
            options: string[];
            correctOptionIndex: number;
          }>;
        };

        // Create assessment record
        const assessmentResult = await createAssessment({
          userId: ctx.user.id,
          skillProfileId: input.skillProfileId,
          status: "in_progress",
          totalQuestions: parsed.questions.length,
          specialization: profile.specialization ?? undefined,
          experienceLevel: profile.experienceLevel ?? undefined,
        });

        // Get the inserted ID
        const allAssessments = await getAssessmentsByUser(ctx.user.id);
        const newAssessment = allAssessments[0];
        if (!newAssessment) throw new Error("Failed to create assessment");

        // Insert MCQ questions
        await createQuestions(
          parsed.questions.map((q, i) => ({
            assessmentId: newAssessment.id,
            questionText: q.questionText,
            skill: q.skill,
            difficulty: q.difficulty,
            orderIndex: i,
            questionType: "mcq" as const,
            options: q.options,
            correctOptionIndex: q.correctOptionIndex,
          }))
        );

        return { assessmentId: newAssessment.id };
      }),

    // Submit a single answer (MCQ or open-ended)
    submitAnswer: protectedProcedure
      .input(
        z.object({
          assessmentId: z.number(),
          questionId: z.number(),
          answerText: z.string().optional(),
          selectedOptionIndex: z.number().optional(),
          timeTakenSeconds: z.number().optional(),
          isSkipped: z.boolean().optional(),
          tabSwitchDetected: z.boolean().optional(),
          windowBlurDetected: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const assessment = await getAssessmentById(input.assessmentId);
        if (!assessment || assessment.userId !== ctx.user.id) {
          throw new Error("Assessment not found");
        }

        const existing = await getAnswerByQuestionAndAssessment(
          input.questionId,
          input.assessmentId
        );
        if (existing) return existing;

        // Get the question to check if it's MCQ
        const questions = await getQuestionsByAssessment(input.assessmentId);
        const currentQuestion = questions.find((q) => q.id === input.questionId);

        // For MCQ, determine if answer is correct
        let isCorrect = false;
        if (currentQuestion?.questionType === "mcq" && input.selectedOptionIndex !== undefined) {
          isCorrect = input.selectedOptionIndex === currentQuestion.correctOptionIndex;
        }

        await createAnswer({
          assessmentId: input.assessmentId,
          questionId: input.questionId,
          userId: ctx.user.id,
          answerText: input.answerText,
          selectedOptionIndex: input.selectedOptionIndex,
          timeTakenSeconds: input.timeTakenSeconds,
          isSkipped: input.isSkipped ?? false,
          isCorrect: isCorrect,
        });

        await incrementAnsweredQuestions(input.assessmentId);
        return { success: true, isCorrect };
      }),

    // Complete assessment and generate report
    complete: protectedProcedure
      .input(z.object({ assessmentId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const assessment = await getAssessmentById(input.assessmentId);
        if (!assessment || assessment.userId !== ctx.user.id) {
          throw new Error("Assessment not found");
        }

        const qs = await getQuestionsByAssessment(input.assessmentId);
        const ans = await getAnswersByAssessment(input.assessmentId);

        // Build Q&A pairs for evaluation (MCQ or open-ended)
        const qaPairs = qs.map((q) => {
          const answer = ans.find((a) => a.questionId === q.id);
          let userAnswer = "";
          let isCorrect = false;
          
          if (q.questionType === "mcq") {
            // MCQ: get the selected option text
            if (answer?.selectedOptionIndex !== undefined && q.options) {
              const opts = q.options as string[];
              const idx = answer.selectedOptionIndex as number;
              userAnswer = opts[idx] ?? "";
              isCorrect = answer.isCorrect ?? false;
            }
          } else {
            // Open-ended: use answer text
            userAnswer = answer?.answerText ?? "";
          }
          
          return {
            question: q.questionText,
            skill: q.skill ?? "General",
            difficulty: q.difficulty ?? "medium",
            questionType: q.questionType ?? "mcq",
            isCorrect: isCorrect,
            expectedAnswer: q.expectedAnswer ?? "",
            userAnswer: userAnswer,
            isSkipped: answer?.isSkipped ?? true,
          };
        });

        // AI evaluation
        const evalResponse = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are an expert technical evaluator. Evaluate interview answers objectively and provide detailed feedback. Return ONLY valid JSON.`,
            },
            {
              role: "user",
              content: `Evaluate these technical interview answers for a ${assessment.experienceLevel} ${assessment.specialization} developer.

Questions and Answers:
${qaPairs
  .map(
    (qa, i) => `
Q${i + 1} [${qa.skill}] [${qa.difficulty}]: ${qa.question}
Expected: ${qa.expectedAnswer}
Answer: ${qa.isSkipped ? "[SKIPPED]" : qa.userAnswer || "[NO ANSWER]"}
`
  )
  .join("\n")}

Provide:
1. Score for each question (0-100)
2. Brief feedback for each answer
3. Overall assessment report

Return JSON:
{
  "questionEvaluations": [
    { "questionIndex": 0, "score": 85, "feedback": "string" }
  ],
  "report": {
    "overallScore": 75,
    "jobReadinessScore": 70,
    "skillScores": [
      { "skill": "React", "score": 80, "level": "Proficient", "questionsCount": 2 }
    ],
    "strengths": ["strength1", "strength2"],
    "weaknesses": ["weakness1", "weakness2"],
    "missingSkills": ["skill1", "skill2"],
    "recommendations": ["recommendation1", "recommendation2"],
    "summary": "Overall assessment summary",
    "marketReadinessDetails": "Detailed job market readiness analysis"
  }
}`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "assessment_evaluation",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  questionEvaluations: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        questionIndex: { type: "integer" },
                        score: { type: "number" },
                        feedback: { type: "string" },
                      },
                      required: ["questionIndex", "score", "feedback"],
                      additionalProperties: false,
                    },
                  },
                  report: {
                    type: "object",
                    properties: {
                      overallScore: { type: "number" },
                      jobReadinessScore: { type: "number" },
                      skillScores: {
                        type: "array",
                        items: {
                          type: "object",
                          properties: {
                            skill: { type: "string" },
                            score: { type: "number" },
                            level: { type: "string" },
                            questionsCount: { type: "integer" },
                          },
                          required: ["skill", "score", "level", "questionsCount"],
                          additionalProperties: false,
                        },
                      },
                      strengths: { type: "array", items: { type: "string" } },
                      weaknesses: { type: "array", items: { type: "string" } },
                      missingSkills: { type: "array", items: { type: "string" } },
                      recommendations: { type: "array", items: { type: "string" } },
                      summary: { type: "string" },
                      marketReadinessDetails: { type: "string" },
                    },
                    required: [
                      "overallScore",
                      "jobReadinessScore",
                      "skillScores",
                      "strengths",
                      "weaknesses",
                      "missingSkills",
                      "recommendations",
                      "summary",
                      "marketReadinessDetails",
                    ],
                    additionalProperties: false,
                  },
                },
                required: ["questionEvaluations", "report"],
                additionalProperties: false,
              },
            },
          },
        });

        const rawEvalContent = evalResponse.choices[0]?.message?.content;
        const evalContent = typeof rawEvalContent === 'string' ? rawEvalContent : null;
        if (!evalContent) throw new Error("Evaluation failed");

        const evalParsed = JSON.parse(evalContent) as {
          questionEvaluations: Array<{ questionIndex: number; score: number; feedback: string }>;
          report: AssessmentReport;
        };

        // Update individual answers with scores
        for (const ev of evalParsed.questionEvaluations) {
          const q = qs[ev.questionIndex];
          if (!q) continue;
          const a = ans.find((a) => a.questionId === q.id);
          if (a) {
            await updateAnswer(a.id, {
              score: ev.score,
              feedback: ev.feedback,
              evaluatedAt: new Date(),
            });
          }
        }

        // Update assessment with report
        await updateAssessmentStatus(input.assessmentId, "completed", {
          overallScore: evalParsed.report.overallScore,
          jobReadinessScore: evalParsed.report.jobReadinessScore,
          reportData: evalParsed.report,
          completedAt: new Date(),
          answeredQuestions: ans.length,
        });

        // Notify owner
        try {
          await notifyOwner({
            title: `New Assessment Completed – ${ctx.user.name ?? ctx.user.email ?? "User"}`,
            content: `User: ${ctx.user.name ?? ctx.user.email ?? ctx.user.openId}
Specialization: ${assessment.specialization ?? "N/A"}
Level: ${assessment.experienceLevel ?? "N/A"}
Overall Score: ${evalParsed.report.overallScore}/100
Job Readiness: ${evalParsed.report.jobReadinessScore}/100
Summary: ${evalParsed.report.summary}`,
          });
        } catch (e) {
          console.warn("Owner notification failed:", e);
        }

        return { report: evalParsed.report };
      }),
  }),
});

export type AppRouter = typeof appRouter;

import { useState, useCallback, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Brain,
  FileText,
  Upload,
  X,
  Plus,
  ChevronRight,
  Loader2,
  CheckCircle,
  ArrowLeft,
  Sparkles,
  Code2,
  User,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { SPECIALIZATION_CATEGORIES, searchSpecializations } from "@/lib/specializations";
import { Search } from "lucide-react";

const SPECIALIZATIONS = [
  // Healthcare
  "Medicine",
  "Doctor of Pharmacy (PharmD)",
  "Pharmacy",
  "Nursing",
  "Physical Therapy",
  "Occupational Therapy",
  "Clinical Nutrition and Dietetics",
  "Medical Laboratory Sciences",
  "Medical Imaging and Radiologic Technology",
  "Speech and Hearing Sciences",
  // Engineering
  "Civil Engineering",
  "Electrical Engineering",
  "Mechanical Engineering",
  "Industrial Engineering",
  "Biomedical Engineering",
  "Architecture Engineering",
  "Computer Engineering",
  // Computer Science & IT
  "Computer Science",
  "Software Engineering",
  "Computer Information Systems",
  "Business Information Technology",
  "Cybersecurity",
  "Information Technology",
  // Science
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "Biotechnology",
  // Business & Finance
  "Business Administration",
  "Accounting",
  "Finance and Banking",
  "Economics",
  "Financial Economics",
  "Management Information Systems",
  "Risk Management and Insurance",
  "Accounting and Commercial Law",
  // Arts & Languages
  "Arabic Language and Literature",
  "English Language and Literature",
  "English Literature and Cultural Studies",
  "History",
  "Sociology",
  // Social Sciences
  "International Relations and Strategic Studies",
  "Psychological Counseling",
  // Education
  "Classroom Teacher Education",
  "Early Childhood Education",
  "Special Education",
  "Art Education",
  // Tourism & Hospitality
  "Tourism Management",
  "Hotel Management",
  "Heritage Resources and Museum Management",
  "Conservation of Cultural Resources",
  // Environment & Agriculture
  "Geology and Environment",
  "Land and Water Management",
  "Water and Environmental Management",
  "Climate Change and Sustainability of Drylands",
  // Sports
  "Sports Management and Coaching",
  "Sports Rehabilitation",
  // Other
  "Other",
];

const EXPERIENCE_LEVELS = [
  { value: "junior", label: "Junior", desc: "0–2 years", color: "text-emerald-400" },
  { value: "mid", label: "Mid-Level", desc: "2–5 years", color: "text-blue-400" },
  { value: "senior", label: "Senior", desc: "5–10 years", color: "text-violet-400" },
  { value: "lead", label: "Lead / Principal", desc: "10+ years", color: "text-amber-400" },
] as const;

const POPULAR_SKILLS = [
  "JavaScript", "TypeScript", "Python", "Java", "C++", "C#", "Go", "Rust",
  "PHP", "Ruby", "Swift", "Kotlin", "R", "MATLAB",
  "React", "Vue.js", "Angular", "Next.js", "Svelte", "HTML5", "CSS3",
  "Tailwind CSS", "Bootstrap", "Material UI",
  "Node.js", "Express", "Django", "FastAPI", "Spring Boot", "Laravel",
  "ASP.NET", "Flask", "Gin", "Actix",
  "SQL", "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch",
  "Cassandra", "DynamoDB", "Firebase",
  "Docker", "Kubernetes", "AWS", "Azure", "Google Cloud", "Terraform",
  "Jenkins", "GitLab CI", "GitHub Actions",
  "TensorFlow", "PyTorch", "Scikit-learn", "Pandas", "NumPy",
  "Machine Learning", "Deep Learning", "NLP", "Computer Vision",
  "Git", "GraphQL", "REST APIs", "Microservices", "Linux",
  "Cybersecurity", "Blockchain", "IoT",
  "Communication", "Leadership", "Problem Solving", "Teamwork",
  "Project Management", "Agile", "Scrum", "Time Management",
  "Critical Thinking", "Creativity",
];

type Mode = "choose" | "resume" | "manual";

export default function SetupProfile() {
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<Mode>("choose");

  // Resume upload state
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Manual entry state
  const [specialization, setSpecialization] = useState("");
  const [customSpec, setCustomSpec] = useState("");
  const [experienceLevel, setExperienceLevel] = useState<"junior" | "mid" | "senior" | "lead">("mid");
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState("");
  const [specializationSearch, setSpecializationSearch] = useState("");

  const uploadResume = trpc.skillProfile.uploadResume.useMutation();
  const analyzeResume = trpc.skillProfile.analyzeResume.useMutation();
  const createManual = trpc.skillProfile.createManual.useMutation();

  // ─── File handling ────────────────────────────────────────────────────────

  const handleFile = useCallback((f: File) => {
    const validTypes = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];
    if (!validTypes.includes(f.type)) {
      toast.error("Please upload a PDF or image file (JPG, PNG)");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      toast.error("File size must be under 10MB");
      return;
    }
    setFile(f);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      const f = e.dataTransfer.files[0];
      if (f) handleFile(f);
    },
    [handleFile]
  );

  const handleResumeSubmit = async () => {
    if (!file) return;
    setAnalyzing(true);
    try {
      // Read file as base64
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(",")[1] ?? "");
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      // Upload to storage and extract text
      const uploaded = await uploadResume.mutateAsync({
        fileName: file.name,
        fileBase64: base64,
        mimeType: file.type,
      });

      // Use the extracted text from the server
      const resumeText = uploaded.extractedText || `[PDF Resume: ${file.name}]`;

      const result = await analyzeResume.mutateAsync({
        resumeText,
        fileName: file.name,
        fileKey: uploaded.key,
        fileUrl: uploaded.url,
      });

      toast.success("Resume analyzed successfully!");
      navigate(`/assessment/start/${result.profile.insertId ?? result.profile}`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to analyze resume. Please try manual entry.");
    } finally {
      setAnalyzing(false);
    }
  };

  // ─── Skills management ────────────────────────────────────────────────────

  const addSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (!trimmed || skills.includes(trimmed) || skills.length >= 20) return;
    setSkills((prev) => [...prev, trimmed]);
    setSkillInput("");
  };

  const removeSkill = (skill: string) => {
    setSkills((prev) => prev.filter((s) => s !== skill));
  };

  const handleManualSubmit = async () => {
    const spec = specialization === "custom" ? customSpec : specialization;
    if (!spec) {
      toast.error("Please select or enter a specialization");
      return;
    }
    if (skills.length < 1) {
      toast.error("Please add at least 1 skill");
      return;
    }
    try {
      const result = await createManual.mutateAsync({
        specialization: spec,
        experienceLevel,
        skills,
      });
      toast.success("Profile created!");
      navigate(`/assessment/start/${result.insertId}`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to create profile");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/50">
        <div className="container">
          <div className="flex items-center gap-4 h-16">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => (mode === "choose" ? navigate("/dashboard") : setMode("choose"))}
              className="text-muted-foreground"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              {mode === "choose" ? "Dashboard" : "Back"}
            </Button>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">New Assessment</span>
            </div>
          </div>
        </div>
      </div>

      <div className="container py-12">
        <AnimatePresence mode="wait">
          {/* ─── Choose Mode ─────────────────────────────────────────────────── */}
          {mode === "choose" && (
            <motion.div
              key="choose"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-2xl mx-auto"
            >
              <div className="text-center mb-10">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-7 h-7 text-primary" />
                </div>
                <h1 className="text-2xl font-bold mb-2">Set Up Your Skill Profile</h1>
                <p className="text-muted-foreground">
                  Choose how you'd like to provide your skills information
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <button
                  onClick={() => setMode("resume")}
                  className="group card-hover text-left rounded-2xl p-6 border border-border/50 bg-card hover:border-primary/40 transition-all"
                >
                  <div className="w-12 h-12 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mb-4 group-hover:bg-violet-500/20 transition-colors">
                    <FileText className="w-6 h-6 text-violet-400" />
                  </div>
                  <h3 className="font-semibold mb-1.5">Upload Resume</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Upload your PDF resume and let AI automatically extract your skills and experience.
                  </p>
                  <div className="flex items-center text-sm text-primary font-medium">
                    Get started <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </button>

                <button
                  onClick={() => setMode("manual")}
                  className="group card-hover text-left rounded-2xl p-6 border border-border/50 bg-card hover:border-primary/40 transition-all"
                >
                  <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4 group-hover:bg-cyan-500/20 transition-colors">
                    <Code2 className="w-6 h-6 text-cyan-400" />
                  </div>
                  <h3 className="font-semibold mb-1.5">Enter Skills Manually</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Manually specify your technical skills, specialization, and experience level.
                  </p>
                  <div className="flex items-center text-sm text-primary font-medium">
                    Get started <ChevronRight className="w-4 h-4 ml-1" />
                  </div>
                </button>
              </div>
            </motion.div>
          )}

          {/* ─── Resume Upload ────────────────────────────────────────────────── */}
          {mode === "resume" && (
            <motion.div
              key="resume"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-xl mx-auto"
            >
              <div className="text-center mb-8">
                <h1 className="text-2xl font-bold mb-2">Upload Your Resume</h1>
                <p className="text-muted-foreground text-sm">
                  Upload your PDF resume. Our AI will extract your skills and create a personalized assessment.
                </p>
              </div>

              {/* Drop zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => !file && fileInputRef.current?.click()}
                className={`
                  relative rounded-2xl border-2 border-dashed p-12 text-center cursor-pointer transition-all
                  ${dragOver ? "border-primary bg-primary/5" : "border-border/50 hover:border-primary/40 hover:bg-card/50"}
                  ${file ? "border-emerald-500/50 bg-emerald-500/5 cursor-default" : ""}
                `}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
                />

                {file ? (
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                      <CheckCircle className="w-7 h-7 text-emerald-400" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{file.name}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => { e.stopPropagation(); setFile(null); }}
                      className="text-muted-foreground hover:text-destructive"
                    >
                      <X className="w-4 h-4 mr-1" /> Remove
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
                      <Upload className="w-7 h-7 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Drop your resume here</p>
                      <p className="text-sm text-muted-foreground mt-0.5">or click to browse</p>
                    </div>
                    <p className="text-xs text-muted-foreground">PDF or Image (JPG, PNG) · Max 10MB</p>
                  </div>
                )}
              </div>

              <div className="mt-6 flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setMode("choose")}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button
                  onClick={handleResumeSubmit}
                  disabled={!file || analyzing}
                  className="flex-1 glow-sm"
                >
                  {analyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-2" />
                      Analyze & Continue
                    </>
                  )}
                </Button>
              </div>

              <p className="text-center text-xs text-muted-foreground mt-4">
                Your resume is stored securely and linked to your account
              </p>
            </motion.div>
          )}

          {/* ─── Manual Entry ─────────────────────────────────────────────────── */}
          {mode === "manual" && (
            <motion.div
              key="manual"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-2xl mx-auto"
            >
              <div className="text-center mb-8">
                <h1 className="text-2xl font-bold mb-2">Enter Your Skills</h1>
                <p className="text-muted-foreground text-sm">
                  Tell us about your technical background to generate a personalized assessment.
                </p>
              </div>

              <div className="space-y-6">
                {/* Specialization with Categories */}
                <div className="rounded-2xl border border-border/50 bg-card p-6">
                  <Label className="text-sm font-semibold mb-6 block">Specialization</Label>
                  
                  {/* Search Input - Prominent */}
                  <div className="relative mb-6">
                    <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-primary" />
                    <Input
                      placeholder="Search specializations... (e.g., Medicine, Software, Engineering)"
                      value={specializationSearch}
                      onChange={(e) => setSpecializationSearch(e.target.value)}
                      className="pl-12 py-3 text-base bg-primary/5 border-2 border-primary/30 rounded-xl focus:border-primary focus:bg-primary/10 transition-all"
                      autoFocus
                    />
                  </div>

                  {/* Categories / Search Results */}
                  <div className="space-y-4 max-h-96 overflow-y-auto border-t border-border/30 pt-4">
                    {specializationSearch ? (
                      // Search results
                      Object.entries(searchSpecializations(specializationSearch)).length > 0 ? (
                        Object.entries(searchSpecializations(specializationSearch)).map(([category, specs]) => (
                        <div key={category}>
                          <p className="text-xs font-semibold text-muted-foreground mb-2">{category}</p>
                          <div className="grid grid-cols-2 gap-2">
                            {specs.map((spec) => (
                              <button
                                key={spec}
                                onClick={() => {
                                  setSpecialization(spec);
                                  setSpecializationSearch("");
                                }}
                                className={`text-left text-xs px-3 py-2 rounded-lg border transition-all ${
                                  specialization === spec
                                    ? "border-primary bg-primary/10 text-primary"
                                    : "border-border/50 text-muted-foreground hover:border-primary/30 hover:text-foreground"
                                }`}
                              >
                                {spec}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))
                      ) : (
                        <div className="text-center py-12">
                          <Search className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
                          <p className="text-sm text-muted-foreground">No specializations found for "<strong>{specializationSearch}</strong>"</p>
                          <p className="text-xs text-muted-foreground/60 mt-2">Try different keywords</p>
                        </div>
                      )
                    ) : (
                      // All categories
                      Object.entries(SPECIALIZATION_CATEGORIES).map(([category, specs]) => (
                        <div key={category}>
                          <p className="text-xs font-semibold text-muted-foreground mb-2">{category}</p>
                          <div className="grid grid-cols-2 gap-2">
                            {specs.map((spec) => (
                              <button
                                key={spec}
                                onClick={() => setSpecialization(spec)}
                                className={`text-left text-xs px-3 py-2 rounded-lg border transition-all ${
                                  specialization === spec
                                    ? "border-primary bg-primary/10 text-primary"
                                    : "border-border/50 text-muted-foreground hover:border-primary/30 hover:text-foreground"
                                }`}
                              >
                                {spec}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))
                    )}
                    
                    {/* Custom option */}
                    <div>
                      <p className="text-xs font-semibold text-muted-foreground mb-2">Other</p>
                      <button
                        onClick={() => setSpecialization("custom")}
                        className={`w-full text-left text-xs px-3 py-2 rounded-lg border transition-all ${
                          specialization === "custom"
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border/50 text-muted-foreground hover:border-primary/30 hover:text-foreground"
                        }`}
                      >
                        Enter custom specialization...
                      </button>
                      {specialization === "custom" && (
                        <Input
                          placeholder="Enter your specialization"
                          value={customSpec}
                          onChange={(e) => setCustomSpec(e.target.value)}
                          className="mt-2 bg-secondary/50 border-border/50"
                        />
                      )}
                    </div>
                  </div>
                </div>

                {/* Experience Level */}
                <div className="rounded-2xl border border-border/50 bg-card p-6">
                  <Label className="text-sm font-semibold mb-3 block">Experience Level</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {EXPERIENCE_LEVELS.map((level) => (
                      <button
                        key={level.value}
                        onClick={() => setExperienceLevel(level.value)}
                        className={`text-center p-3 rounded-xl border transition-all ${
                          experienceLevel === level.value
                            ? "border-primary bg-primary/10"
                            : "border-border/50 hover:border-primary/30"
                        }`}
                      >
                        <div className={`font-semibold text-sm ${level.color}`}>{level.label}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{level.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Skills */}
                <div className="rounded-2xl border border-border/50 bg-card p-6">
                  <Label className="text-sm font-semibold mb-3 block">
                    Technical Skills
                    <span className="text-muted-foreground font-normal ml-2">
                      ({skills.length}/20)
                    </span>
                  </Label>

                  {/* Selected skills */}
                  {skills.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {skills.map((skill) => (
                        <Badge
                          key={skill}
                          variant="secondary"
                          className="pl-2.5 pr-1.5 py-1 bg-primary/10 text-primary border-primary/20 text-xs"
                        >
                          {skill}
                          <button
                            onClick={() => removeSkill(skill)}
                            className="ml-1.5 hover:text-destructive transition-colors"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Skill input with search */}
                  <div className="mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-5 h-5 text-primary" />
                      <Input
                        type="text"
                        placeholder="Search or add a skill (e.g., React, Python, Docker)"
                        value={skillInput}
                        onChange={(e) => setSkillInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            addSkill(skillInput);
                          }
                        }}
                        className="pl-10 py-2.5 bg-secondary/50 border border-border/50 rounded-lg"
                      />
                    </div>
                  </div>

                  {/* Suggested skills based on search */}
                  {skillInput && (
                    <div className="mb-4 p-3 bg-secondary/30 rounded-lg border border-border/30">
                      <p className="text-xs text-muted-foreground mb-2">Suggestions for "{skillInput}":</p>
                      <div className="flex flex-wrap gap-2">
                        {POPULAR_SKILLS.filter((s) => 
                          s.toLowerCase().includes(skillInput.toLowerCase()) && !skills.includes(s)
                        ).slice(0, 8).map((skill) => (
                          <button
                            key={skill}
                            onClick={() => {
                              addSkill(skill);
                              setSkillInput("");
                            }}
                            className="text-xs px-3 py-1.5 rounded-md bg-primary/10 text-primary border border-primary/30 hover:bg-primary/20 transition-all"
                          >
                            + {skill}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Popular skills */}
                  <div>
                    <p className="text-xs text-muted-foreground mb-2">Popular skills:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {POPULAR_SKILLS.filter((s) => !skills.includes(s)).slice(0, 16).map((skill) => (
                        <button
                          key={skill}
                          onClick={() => addSkill(skill)}
                          className="text-xs px-2.5 py-1 rounded-md border border-border/50 text-muted-foreground hover:border-primary/40 hover:text-foreground transition-all"
                        >
                          + {skill}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setMode("choose")}
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handleManualSubmit}
                    disabled={createManual.isPending || skills.length < 1 || !specialization}
                    className="flex-1 glow-sm"
                  >
                    {createManual.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      <>
                        <Brain className="w-4 h-4 mr-2" />
                        Generate Assessment
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

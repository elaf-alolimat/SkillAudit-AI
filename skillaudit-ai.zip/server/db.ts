import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  skillProfiles,
  assessments,
  questions,
  answers,
  InsertSkillProfile,
  InsertAssessment,
  InsertQuestion,
  InsertAnswer,
  AssessmentReport,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach((field) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  });

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Skill Profiles ───────────────────────────────────────────────────────────

export async function createSkillProfile(data: InsertSkillProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(skillProfiles).values(data);
  return result[0];
}

export async function getSkillProfilesByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(skillProfiles)
    .where(eq(skillProfiles.userId, userId))
    .orderBy(desc(skillProfiles.createdAt));
}

export async function getSkillProfileById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(skillProfiles).where(eq(skillProfiles.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Assessments ─────────────────────────────────────────────────────────────

export async function createAssessment(data: InsertAssessment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(assessments).values(data);
  return result[0];
}

export async function getAssessmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(assessments).where(eq(assessments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAssessmentsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(assessments)
    .where(eq(assessments.userId, userId))
    .orderBy(desc(assessments.createdAt));
}

export async function updateAssessmentStatus(
  id: number,
  status: "pending" | "in_progress" | "completed" | "abandoned",
  extra?: Partial<{
    overallScore: number;
    jobReadinessScore: number;
    reportData: AssessmentReport;
    completedAt: Date;
    answeredQuestions: number;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(assessments)
    .set({ status, ...extra })
    .where(eq(assessments.id, id));
}

export async function incrementAnsweredQuestions(assessmentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const current = await getAssessmentById(assessmentId);
  if (!current) return;
  await db
    .update(assessments)
    .set({ answeredQuestions: (current.answeredQuestions ?? 0) + 1 })
    .where(eq(assessments.id, assessmentId));
}

// ─── Questions ────────────────────────────────────────────────────────────────

export async function createQuestions(data: InsertQuestion[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (data.length === 0) return;
  await db.insert(questions).values(data);
}

export async function getQuestionsByAssessment(assessmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(questions)
    .where(eq(questions.assessmentId, assessmentId))
    .orderBy(questions.orderIndex);
}

// ─── Answers ──────────────────────────────────────────────────────────────────

export async function createAnswer(data: InsertAnswer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(answers).values(data);
  return result[0];
}

export async function getAnswersByAssessment(assessmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(answers).where(eq(answers.assessmentId, assessmentId));
}

export async function updateAnswer(
  id: number,
  data: Partial<{ score: number; feedback: string; evaluatedAt: Date }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(answers).set(data).where(eq(answers.id, id));
}

export async function getAnswerByQuestionAndAssessment(
  questionId: number,
  assessmentId: number
) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(answers)
    .where(and(eq(answers.questionId, questionId), eq(answers.assessmentId, assessmentId)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

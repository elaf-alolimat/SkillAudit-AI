import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Brain,
  Loader2,
  Clock,
  ChevronRight,
  ChevronLeft,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useRef, useCallback } from "react";

const TOTAL_ASSESSMENT_TIME = 300; // 5 minutes total for all 10 questions

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function TimeWarning({ timeLeft }: { timeLeft: number }) {
  if (timeLeft > 60) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 flex items-center gap-2"
    >
      <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
      <span className="text-sm text-red-300">Time running out!</span>
    </motion.div>
  );
}

export default function AssessmentTake() {
  const params = useParams<{ assessmentId: string }>();
  const assessmentId = parseInt(params.assessmentId ?? "0");
  const [, navigate] = useLocation();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState<Record<number, number>>({}); // MCQ: store selected option index
  const [submitted, setSubmitted] = useState<Set<number>>(new Set());
  const [timeLeft, setTimeLeft] = useState(TOTAL_ASSESSMENT_TIME);
  const [completing, setCompleting] = useState(false);
  const [cheatingAttempts, setCheatingAttempts] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const { data, isLoading } = trpc.assessment.getWithQuestions.useQuery(
    { id: assessmentId },
    { enabled: !!assessmentId }
  );

  const submitAnswer = trpc.assessment.submitAnswer.useMutation();
  const completeAssessment = trpc.assessment.complete.useMutation();

  const questions = data?.questions ?? [];
  const currentQuestion = questions[currentIndex];
  const totalQuestions = questions.length;
  const progress = ((currentIndex + 1) / totalQuestions) * 100;

  // Global timer for entire assessment
  useEffect(() => {
    if (completing || !data?.assessment) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Time's up - auto-complete assessment
          handleCompleteAssessment();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [completing, data?.assessment]);

  // Detect cheating attempts (tab switch, window blur)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setCheatingAttempts((prev) => prev + 1);
        if (cheatingAttempts >= 1) {
          toast.error("Cheating detected! Generating new questions...");
          handleCompleteAssessment();
        }
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [cheatingAttempts]);

  const handleCompleteAssessment = useCallback(async () => {
    if (completing) return;
    setCompleting(true);

    try {
      if (timerRef.current) clearInterval(timerRef.current);

      await completeAssessment.mutateAsync({ assessmentId });
      toast.success("Assessment completed!");
      navigate(`/report/${assessmentId}`);
    } catch (err) {
      toast.error("Failed to complete assessment");
      setCompleting(false);
    }
  }, [assessmentId, completeAssessment, navigate, completing]);

  const handleSelectOption = useCallback(
    async (optionIndex: number) => {
      if (!currentQuestion) return;

      try {
        // Submit the answer (allow re-submission for changing answers)
        await submitAnswer.mutateAsync({
          assessmentId,
          questionId: currentQuestion.id,
          selectedOptionIndex: optionIndex,
          timeTakenSeconds: TOTAL_ASSESSMENT_TIME - timeLeft,
        });

        setSelectedOptions((prev) => ({
          ...prev,
          [currentQuestion.id]: optionIndex,
        }));
        
        // Mark as submitted only on first submission
        if (!submitted.has(currentQuestion.id)) {
          setSubmitted((prev) => new Set(prev).add(currentQuestion.id));
        }

        // Auto-move to next question after 500ms
        setTimeout(() => {
          if (currentIndex < totalQuestions - 1) {
            setCurrentIndex(currentIndex + 1);
          } else {
            // All questions done
            handleCompleteAssessment();
          }
        }, 500);
      } catch (err) {
        toast.error("Failed to submit answer");
      }
    },
    [currentQuestion, submitted, currentIndex, totalQuestions, assessmentId, timeLeft, submitAnswer, handleCompleteAssessment]
  );

  const handleSkip = useCallback(async () => {
    if (!currentQuestion || submitted.has(currentQuestion.id)) return;

    try {
      // Submit as skipped
      await submitAnswer.mutateAsync({
        assessmentId,
        questionId: currentQuestion.id,
        isSkipped: true,
        timeTakenSeconds: TOTAL_ASSESSMENT_TIME - timeLeft,
      });

      setSubmitted((prev) => new Set(prev).add(currentQuestion.id));

      // Move to next question
      if (currentIndex < totalQuestions - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        // All questions done
        handleCompleteAssessment();
      }
    } catch (err) {
      toast.error("Failed to skip question");
    }
  }, [currentQuestion, submitted, currentIndex, totalQuestions, assessmentId, timeLeft, submitAnswer, handleCompleteAssessment]);

  const handlePrevious = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  }, [currentIndex]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No questions found</p>
        </div>
      </div>
    );
  }

  const isAnswered = submitted.has(currentQuestion.id);
  const selectedOption = selectedOptions[currentQuestion.id];
  const options = (currentQuestion.options as string[]) ?? [];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container py-4">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              <span className="font-semibold">SkillAudit Assessment</span>
            </div>
            <div className="flex items-center gap-3">
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg ${
                timeLeft <= 60 ? "bg-red-500/10 text-red-400" : "bg-primary/10 text-primary"
              }`}>
                <Clock className="w-4 h-4" />
                <span className="text-sm font-mono font-semibold">{formatTime(timeLeft)}</span>
              </div>
              <Badge variant="secondary" className="text-xs">
                {currentIndex + 1} / {totalQuestions}
              </Badge>
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1 bg-secondary rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-cyan-400"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container py-8">
        <TimeWarning timeLeft={timeLeft} />

        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="max-w-2xl mx-auto"
          >
            {/* Question */}
            <div className="mb-8">
              <div className="flex items-start justify-between gap-4 mb-4">
                <h2 className="text-xl font-bold leading-relaxed">{currentQuestion.questionText}</h2>
                <Badge
                  variant="secondary"
                  className={`text-xs flex-shrink-0 capitalize ${
                    currentQuestion.difficulty === "easy"
                      ? "bg-emerald-500/10 text-emerald-400"
                      : currentQuestion.difficulty === "medium"
                      ? "bg-amber-500/10 text-amber-400"
                      : "bg-red-500/10 text-red-400"
                  }`}
                >
                  {currentQuestion.difficulty}
                </Badge>
              </div>
              {currentQuestion.skill && (
                <p className="text-sm text-muted-foreground">
                  Skill: <span className="text-foreground font-medium">{currentQuestion.skill}</span>
                </p>
              )}
            </div>

            {/* MCQ Options */}
            <div className="space-y-3 mb-8">
              {options.map((option, idx) => (
                <motion.button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={false}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                    selectedOption === idx
                      ? "border-primary bg-primary/10"
                      : "border-border/50 bg-card hover:border-primary/50"
                  } cursor-pointer`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                        selectedOption === idx
                          ? "border-primary bg-primary"
                          : "border-border/50"
                      }`}
                    >
                      {selectedOption === idx && (
                        <CheckCircle2 className="w-4 h-4 text-primary-foreground" />
                      )}
                    </div>
                    <span className="font-medium">{option}</span>
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-between gap-3">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentIndex === 0}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>

              <div className="flex items-center gap-2">
                {!isAnswered && (
                  <Button
                    variant="ghost"
                    onClick={handleSkip}
                    className="text-muted-foreground"
                  >
                    Skip
                  </Button>
                )}
              </div>

              {isAnswered ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2 text-emerald-400"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium">Answered</span>
                </motion.div>
              ) : (
                <Button disabled className="glow-sm">
                  Select an option
                </Button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Cheating warning */}
        {cheatingAttempts > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 rounded-lg border border-red-500/30 bg-red-500/10 p-4 flex items-center gap-3"
          >
            <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-red-300">Cheating Detected</p>
              <p className="text-xs text-red-400 mt-0.5">
                Switching tabs or minimizing the window will result in new questions being generated.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

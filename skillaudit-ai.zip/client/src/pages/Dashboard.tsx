import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import {
  Brain,
  Plus,
  FileText,
  BarChart3,
  Clock,
  TrendingUp,
  Award,
  ChevronRight,
  Loader2,
  Target,
  Zap,
  User,
  LogOut,
  CheckCircle,
  AlertCircle,
} from "lucide-react";
import { motion } from "framer-motion";
import type { AssessmentReport } from "../../../drizzle/schema";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function ScoreBadge({ score }: { score: number | null }) {
  if (score === null) return null;
  const color =
    score >= 80
      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
      : score >= 60
      ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
      : "bg-red-500/10 text-red-400 border-red-500/20";
  return (
    <Badge variant="secondary" className={`text-xs ${color}`}>
      {Math.round(score)}/100
    </Badge>
  );
}

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { user, isAuthenticated, loading, logout } = useAuth();

  const { data: assessments, isLoading: loadingAssessments } = trpc.assessment.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  const { data: profiles, isLoading: loadingProfiles } = trpc.skillProfile.list.useQuery(
    undefined,
    { enabled: isAuthenticated }
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4">
            <Brain className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-xl font-bold mb-2">Sign in to access your dashboard</h2>
          <p className="text-muted-foreground mb-6 text-sm">
            Track your assessments and monitor your progress
          </p>
          <Button onClick={() => { window.location.href = getLoginUrl(); }} className="glow-sm">
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  const completedAssessments = assessments?.filter((a) => a.status === "completed") ?? [];
  const avgScore =
    completedAssessments.length > 0
      ? completedAssessments.reduce((sum, a) => sum + (a.overallScore ?? 0), 0) /
        completedAssessments.length
      : null;
  const bestScore =
    completedAssessments.length > 0
      ? Math.max(...completedAssessments.map((a) => a.overallScore ?? 0))
      : null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Top nav */}
      <nav className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container">
          <div className="flex items-center justify-between h-16">
            <div
              className="flex items-center gap-2.5 cursor-pointer"
              onClick={() => navigate("/")}
            >
              <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-base tracking-tight">
                Skill<span className="gradient-text">Audit</span> AI
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <User className="w-3.5 h-3.5 text-primary" />
                </div>
                <span>{user?.name ?? user?.email ?? "User"}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => logout()}
                className="text-muted-foreground hover:text-foreground"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container py-8">
        {/* Welcome header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8"
        >
          <div>
            <h1 className="text-2xl font-bold">
              Welcome back, {user?.name?.split(" ")[0] ?? "Developer"}
            </h1>
            <p className="text-muted-foreground text-sm mt-0.5">
              Track your skill assessments and monitor your progress
            </p>
          </div>
          <Button onClick={() => navigate("/setup")} className="glow-sm">
            <Plus className="w-4 h-4 mr-2" />
            New Assessment
          </Button>
        </motion.div>

        {/* Stats row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            {
              icon: BarChart3,
              label: "Total Assessments",
              value: assessments?.length ?? 0,
              color: "text-violet-400",
              bg: "bg-violet-500/10",
            },
            {
              icon: CheckCircle,
              label: "Completed",
              value: completedAssessments.length,
              color: "text-emerald-400",
              bg: "bg-emerald-500/10",
            },
            {
              icon: TrendingUp,
              label: "Avg Score",
              value: avgScore !== null ? `${Math.round(avgScore)}/100` : "—",
              color: "text-cyan-400",
              bg: "bg-cyan-500/10",
            },
            {
              icon: Award,
              label: "Best Score",
              value: bestScore !== null ? `${Math.round(bestScore)}/100` : "—",
              color: "text-amber-400",
              bg: "bg-amber-500/10",
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl border border-border/50 bg-card p-5"
            >
              <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center mb-3`}>
                <stat.icon className={`w-4.5 h-4.5 ${stat.color}`} />
              </div>
              <div className="text-xl font-bold">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Progress over time chart */}
        {completedAssessments.length >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="rounded-2xl border border-border/50 bg-card p-6 mb-6"
          >
            <h2 className="font-semibold flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-primary" />
              Score Progress Over Time
            </h2>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart
                data={completedAssessments
                  .slice()
                  .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
                  .map((a, i) => ({
                    name: formatDate(a.createdAt),
                    score: Math.round(a.overallScore ?? 0),
                    readiness: Math.round((a.reportData as AssessmentReport | null)?.jobReadinessScore ?? 0),
                  }))}
                margin={{ top: 5, right: 20, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                <XAxis dataKey="name" tick={{ fill: "oklch(0.55 0.02 260)", fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: "oklch(0.55 0.02 260)", fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "oklch(0.14 0.018 260)",
                    border: "1px solid oklch(0.22 0.02 260)",
                    borderRadius: "8px",
                    color: "oklch(0.95 0.01 260)",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="score"
                  stroke="oklch(0.65 0.22 270)"
                  strokeWidth={2}
                  dot={{ fill: "oklch(0.65 0.22 270)", r: 4 }}
                  name="Overall Score"
                />
                <Line
                  type="monotone"
                  dataKey="readiness"
                  stroke="oklch(0.70 0.20 200)"
                  strokeWidth={2}
                  strokeDasharray="4 2"
                  dot={{ fill: "oklch(0.70 0.20 200)", r: 4 }}
                  name="Job Readiness"
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Assessment history */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                Assessment History
              </h2>
            </div>

            {loadingAssessments ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-20 rounded-xl shimmer" />
                ))}
              </div>
            ) : assessments && assessments.length > 0 ? (
              <div className="space-y-3">
                {assessments.map((assessment) => {
                  const report = assessment.reportData as AssessmentReport | null;
                  return (
                    <div
                      key={assessment.id}
                      className="card-hover rounded-xl border border-border/50 bg-card p-4 cursor-pointer"
                      onClick={() =>
                        assessment.status === "completed"
                          ? navigate(`/report/${assessment.id}`)
                          : assessment.status === "in_progress"
                          ? navigate(`/assessment/${assessment.id}`)
                          : null
                      }
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                              assessment.status === "completed"
                                ? "bg-emerald-500/10"
                                : assessment.status === "in_progress"
                                ? "bg-primary/10"
                                : "bg-secondary"
                            }`}
                          >
                            {assessment.status === "completed" ? (
                              <CheckCircle className="w-4.5 h-4.5 text-emerald-400" />
                            ) : assessment.status === "in_progress" ? (
                              <Zap className="w-4.5 h-4.5 text-primary" />
                            ) : (
                              <Clock className="w-4.5 h-4.5 text-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium text-sm truncate">
                                {assessment.specialization ?? "Technical Assessment"}
                              </span>
                              <Badge
                                variant="secondary"
                                className="text-xs capitalize bg-secondary text-muted-foreground"
                              >
                                {assessment.experienceLevel}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-3 mt-0.5">
                              <span className="text-xs text-muted-foreground">
                                {formatDate(assessment.createdAt)}
                              </span>
                              {assessment.status === "completed" && (
                                <span className="text-xs text-muted-foreground">
                                  {assessment.answeredQuestions}/{assessment.totalQuestions} answered
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          {assessment.status === "completed" && (
                            <ScoreBadge score={assessment.overallScore} />
                          )}
                          {assessment.status === "in_progress" && (
                            <Badge variant="secondary" className="text-xs bg-primary/10 text-primary border-primary/20">
                              In Progress
                            </Badge>
                          )}
                          <ChevronRight className="w-4 h-4 text-muted-foreground" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-border/50 p-12 text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">No assessments yet</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Start your first assessment to see your results here
                </p>
                <Button onClick={() => navigate("/setup")} size="sm" className="glow-sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Start Assessment
                </Button>
              </div>
            )}
          </motion.div>

          {/* Skill profiles sidebar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <Target className="w-4 h-4 text-primary" />
                Skill Profiles
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/setup")}
                className="text-xs text-muted-foreground"
              >
                <Plus className="w-3 h-3 mr-1" />
                New
              </Button>
            </div>

            {loadingProfiles ? (
              <div className="space-y-3">
                {[1, 2].map((i) => (
                  <div key={i} className="h-24 rounded-xl shimmer" />
                ))}
              </div>
            ) : profiles && profiles.length > 0 ? (
              <div className="space-y-3">
                {profiles.slice(0, 5).map((profile) => {
                  const skills = profile.skills as string[];
                  return (
                    <div
                      key={profile.id}
                      className="card-hover rounded-xl border border-border/50 bg-card p-4 cursor-pointer"
                      onClick={() => navigate(`/assessment/start/${profile.id}`)}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div>
                          <p className="text-sm font-medium truncate">{profile.specialization}</p>
                          <p className="text-xs text-muted-foreground capitalize mt-0.5">
                            {profile.experienceLevel} · {profile.source === "resume" ? "From Resume" : "Manual"}
                          </p>
                        </div>
                        <Badge
                          variant="secondary"
                          className="text-xs bg-primary/10 text-primary border-primary/20 flex-shrink-0"
                        >
                          {skills.length} skills
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {skills.slice(0, 3).map((skill) => (
                          <span
                            key={skill}
                            className="text-xs px-1.5 py-0.5 rounded bg-secondary text-muted-foreground"
                          >
                            {skill}
                          </span>
                        ))}
                        {skills.length > 3 && (
                          <span className="text-xs text-muted-foreground">+{skills.length - 3}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-border/50 p-8 text-center">
                <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No profiles yet</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/setup")}
                  className="mt-2 text-primary"
                >
                  Create one
                </Button>
              </div>
            )}

            {/* Quick start CTA */}
            <div className="mt-4 rounded-xl border border-primary/20 bg-primary/5 p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Quick Start</span>
              </div>
              <p className="text-xs text-muted-foreground mb-3">
                Upload your resume or enter skills to get a personalized assessment in minutes.
              </p>
              <Button
                size="sm"
                onClick={() => navigate("/setup")}
                className="w-full glow-sm text-xs"
              >
                Start New Assessment
                <ChevronRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

CREATE TABLE `answers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assessmentId` int NOT NULL,
	`questionId` int NOT NULL,
	`userId` int NOT NULL,
	`answerText` text,
	`score` float,
	`feedback` text,
	`timeTakenSeconds` int,
	`isSkipped` boolean DEFAULT false,
	`evaluatedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `answers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `assessments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`skillProfileId` int NOT NULL,
	`status` enum('pending','in_progress','completed','abandoned') NOT NULL DEFAULT 'pending',
	`totalQuestions` int DEFAULT 0,
	`answeredQuestions` int DEFAULT 0,
	`overallScore` float,
	`jobReadinessScore` float,
	`specialization` varchar(256),
	`experienceLevel` varchar(64),
	`reportData` json,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assessments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`assessmentId` int NOT NULL,
	`questionText` text NOT NULL,
	`skill` varchar(128),
	`difficulty` enum('easy','medium','hard') DEFAULT 'medium',
	`orderIndex` int DEFAULT 0,
	`expectedAnswer` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `skill_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`source` enum('resume','manual') NOT NULL,
	`specialization` varchar(256),
	`experienceLevel` enum('junior','mid','senior','lead') DEFAULT 'mid',
	`skills` json NOT NULL,
	`rawResumeText` text,
	`resumeFileKey` varchar(512),
	`resumeFileUrl` varchar(1024),
	`resumeFileName` varchar(256),
	`aiSummary` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `skill_profiles_id` PRIMARY KEY(`id`)
);

ALTER TABLE `assessments` MODIFY COLUMN `totalQuestions` int DEFAULT 10;--> statement-breakpoint
ALTER TABLE `answers` ADD `selectedOptionIndex` int;--> statement-breakpoint
ALTER TABLE `answers` ADD `isCorrect` boolean;--> statement-breakpoint
ALTER TABLE `assessments` ADD `cheatingDetected` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `assessments` ADD `cheatingDetails` text;--> statement-breakpoint
ALTER TABLE `assessments` ADD `tabSwitchCount` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `assessments` ADD `windowBlurCount` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `questions` ADD `questionType` enum('mcq','open') DEFAULT 'mcq';--> statement-breakpoint
ALTER TABLE `questions` ADD `options` json;--> statement-breakpoint
ALTER TABLE `questions` ADD `correctOptionIndex` int;--> statement-breakpoint
ALTER TABLE `questions` ADD `isCheatingDetected` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `questions` ADD `cheatingReason` varchar(256);